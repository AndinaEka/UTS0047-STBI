<html>
<title>Form Upload</title>
<body>
<form enctype="multipart/form-data" method="POST" action="?menu=querytf2">
<p align="center"><b>Cari Kata Kunci</b></p>
<table width="308" height="82" border="0" align="center">
    <tr>
      <td width="92">Kata Kunci :</td>
      <td width="200"><input type="text" name="keyword"></td>
    </tr>
    <tr>
      <td colspan="2"><input type=submit value=Cari></td>
    </tr>
  </table>
  <br>
</form>