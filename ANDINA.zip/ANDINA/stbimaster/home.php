<html>
<body>
INFORMATION RETRIEVAL: STBI MASTER
<br>
ANDINA EKA SAPUTRI
<br>
14.01.55.0047
</body>
</html>
